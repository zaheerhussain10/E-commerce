<!DOCTYPE html>
<html>
<head>
<title>Contact Manager</title>

<style>
body { font-family: Arial; text-align: center; }
button { padding: 10px; margin-top: 20px; }
</style>

</head>
<body>

<h1>Welcome to Contact Manager</h1>


<a href="addContact.jsp">
    <button>Add Contact</button>
</a>

<a href="viewContacts">
    <button>View Contacts</button>
</a>

<br><br>



</body>
</html>