<!DOCTYPE html>
<html>
<head>
<title>Add Contact</title>
<style>
.container { 
    width: 300px; 
    margin: auto; 
}
input { 
    width: 100%; 
    margin: 10px 0; 
    padding: 8px; 
}
button { 
    width: 100%; 
    padding: 10px; 
}
</style>
</head>
<body>

<div class="container">
    <h2>Add Contact</h2>

<form action="contact" method="post">
    <input type="hidden" name="action" value="add"/>

    Name: <input type="text" name="name" required/><br>
    Email: <input type="email" name="email" required/><br>
    Phone: <input type="text" name="phone" required/><br>

    <input type="submit" value="Add Contact"/>
</form>

</div>

</body>
</html>
