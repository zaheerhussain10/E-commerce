<%@ taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c" %>

<!DOCTYPE html>
<html>
<head>
<title>All Contacts</title>

<style>
table { width: 80%; margin: auto; border-collapse: collapse; }
th, td { padding: 10px; border: 1px solid black; text-align: center; }
</style>

</head>

<body>

<h2 style="text-align:center;">Contact List</h2>

<table>
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Action</th> <!-- ✅ added -->
</tr>

<!-- ✅ JSTL loop -->
<c:forEach var="c" items="${list}">
<tr>
    <td>${c.name}</td>
    <td>${c.email}</td>
    <td>${c.phone}</td>

    <td>
        <a href="contact?action=edit&id=${c.id}">Edit</a>
        <a href="contact?action=delete&id=${c.id}">Delete</a>
    </td>
</tr>
</c:forEach>

</table>

</body>
</html>