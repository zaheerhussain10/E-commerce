<!DOCTYPE html>
<html>
<head>
<title>Add Contact</title>
<style>
.container { width: 300px; margin: auto; }
input { width: 100%; margin: 10px 0; padding: 8px; }
button { width: 100%; padding: 10px; }
</style>
</head>
<body>

<div class="container">
    <h2>Add Contact</h2>

    <form action="addContact" method="post">
        <input type="text" name="name" placeholder="Enter Name" required>
        <input type="email" name="email" placeholder="Enter Email" required>
        <input type="text" name="phone" placeholder="Enter Phone" required>

        <button type="submit">Save Contact</button>
    </form>
</div>

</body>
</html>