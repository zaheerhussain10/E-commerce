package com.contact.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {

    public static Connection getConnection() {

        Connection con = null;

        try {
            // ✅ Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // ✅ Connect to Database
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/contactdb?useSSL=false&serverTimezone=UTC",
                "root",
                "zaheer10"   // 👉 put your correct password
            );

            System.out.println("✅ Database Connected");

        } catch (Exception e) {
            System.out.println("❌ Database Connection Failed");
            e.printStackTrace();
        }

        return con;
    }
}