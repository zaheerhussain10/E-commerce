<%@ page import="java.util.List" %>
<%@ page import="com.contact.model.Contact" %>

<!DOCTYPE html>
<html>
<head>
<title>All Contacts</title>

<style>
table { width: 80%; margin: auto; border-collapse: collapse; }
th, td { padding: 10px; border: 1px solid black; text-align: center; }
</style>

</head>
<body>

<h2 style="text-align:center;">Contact List</h2>

<table>
<tr>
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
</tr>

<%
    List<Contact> list = (List<Contact>) request.getAttribute("contacts");

    if(list != null){
        for(Contact c : list){
%>
<tr>
    <td><%= c.getName() %></td>
    <td><%= c.getEmail() %></td>
    <td><%= c.getPhone() %></td>
</tr>
<%
        }
    }
%>

</table>

</body>
</html>