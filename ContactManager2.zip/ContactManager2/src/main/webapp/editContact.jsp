<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
<form action="contact" method="post">
    <input type="hidden" name="action" value="update"/>

    ID: <input type="text" name="id" value="${contact.id}" readonly/><br>
    Name: <input type="text" name="name" value="${contact.name}"/><br>
    Email: <input type="text" name="email" value="${contact.email}"/><br>
    Phone: <input type="text" name="phone" value="${contact.phone}"/><br>

    <input type="submit" value="Update"/>
</form>
</body>
</html>