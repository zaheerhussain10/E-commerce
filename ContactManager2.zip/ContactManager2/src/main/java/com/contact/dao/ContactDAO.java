package com.contact.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.contact.model.Contact;
import com.contact.util.DBUtil;

public class ContactDAO {

	public boolean addContact(Contact c) {
	    try (Connection con = DBUtil.getConnection()) {

	        if (con == null) {
	            System.out.println("Connection failed ❌");
	            return false;
	        }

	        String sql = "INSERT INTO contacts(name,email,phone) VALUES(?,?,?)";
	        PreparedStatement ps = con.prepareStatement(sql);

	        ps.setString(1, c.getName());
	        ps.setString(2, c.getEmail());
	        ps.setString(3, c.getPhone());

	        int result = ps.executeUpdate();

	        System.out.println("Insert Result: " + result);

	        return result > 0;

	    } catch (Exception e) {
	        System.out.println("ERROR:");
	        e.printStackTrace();
	        return false;
	    }
	}


	public List<Contact> getAllContacts() {
		List<Contact> list = new ArrayList<>();

		try (Connection con = DBUtil.getConnection()) {
			ResultSet rs = con.createStatement().executeQuery("SELECT * FROM contacts");

			while (rs.next()) {
				list.add(new Contact(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4)));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}

	public boolean deleteContact(int id) {
		try (Connection con = DBUtil.getConnection()) {

			PreparedStatement ps = con.prepareStatement("DELETE FROM contacts WHERE id=?");
			ps.setInt(1, id);

			return ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public Contact getContactById(int id) {
		try (Connection con = DBUtil.getConnection()) {

			PreparedStatement ps = con.prepareStatement("SELECT * FROM contacts WHERE id=?");
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();

			if (rs.next()) {
				return new Contact(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	public boolean updateContact(Contact c) {
		try (Connection con = DBUtil.getConnection()) {

			PreparedStatement ps = con.prepareStatement("UPDATE contacts SET name=?, email=?, phone=? WHERE id=?");

			ps.setString(1, c.getName());
			ps.setString(2, c.getEmail());
			ps.setString(3, c.getPhone());
			ps.setInt(4, c.getId());

			return ps.executeUpdate() > 0;

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
}