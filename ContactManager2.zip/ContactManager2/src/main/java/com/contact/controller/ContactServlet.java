package com.contact.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.contact.dao.ContactDAO;
import com.contact.model.Contact;

@WebServlet("/contact")
public class ContactServlet extends HttpServlet {

    ContactDAO dao = new ContactDAO();

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if ("add".equals(action)) {
            Contact c = new Contact();

            c.setName(req.getParameter("name"));
            c.setEmail(req.getParameter("email"));
            c.setPhone(req.getParameter("phone"));

            boolean status = dao.addContact(c);
            sendResult(req, res, status);

        } else if ("update".equals(action)) {
            Contact c = new Contact();

            c.setId(Integer.parseInt(req.getParameter("id")));
            c.setName(req.getParameter("name"));
            c.setEmail(req.getParameter("email"));
            c.setPhone(req.getParameter("phone"));

            boolean status = dao.updateContact(c);
            sendResult(req, res, status);
        }
    }

    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if ("view".equals(action)) {
            req.setAttribute("list", dao.getAllContacts());
            req.getRequestDispatcher("viewContacts.jsp").forward(req, res);

        } else if ("delete".equals(action)) {
            boolean status = dao.deleteContact(
                    Integer.parseInt(req.getParameter("id"))
            );
            sendResult(req, res, status);

        } else if ("edit".equals(action)) {
            Contact c = dao.getContactById(
                    Integer.parseInt(req.getParameter("id"))
            );
            req.setAttribute("contact", c);
            req.getRequestDispatcher("editContact.jsp").forward(req, res);
        }
    }

    private void sendResult(HttpServletRequest req, HttpServletResponse res, boolean status)
            throws ServletException, IOException {

        if (status)
            req.getRequestDispatcher("success.jsp").forward(req, res);
        else
            req.getRequestDispatcher("error.jsp").forward(req, res);
    }
}